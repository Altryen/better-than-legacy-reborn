package useless.legacyui.gui.containers;

import useless.legacyui.settings.LegacySettings;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.client.Minecraft;
import net.minecraft.core.InventoryAction;
import net.minecraft.core.achievement.stat.StatList;
import net.minecraft.core.achievement.stat.StatsCounter;
import net.minecraft.core.block.Blocks;
import net.minecraft.core.data.registry.Registries;
import net.minecraft.core.data.registry.recipe.RecipeSymbol;
import net.minecraft.core.data.registry.recipe.entry.RecipeEntryCrafting;
import net.minecraft.core.entity.player.Player;
import net.minecraft.core.item.Item;
import net.minecraft.core.item.ItemStack;
import net.minecraft.core.item.Items;
import net.minecraft.core.player.gamemode.Gamemodes;
import net.minecraft.core.player.inventory.container.Container;
import net.minecraft.core.player.inventory.container.ContainerCrafting;
import net.minecraft.core.player.inventory.container.ContainerInventory;
import net.minecraft.core.player.inventory.container.ContainerResult;
import net.minecraft.core.player.inventory.menu.MenuAbstract;
import net.minecraft.core.player.inventory.slot.Slot;
import net.minecraft.core.player.inventory.slot.SlotResult;
import net.minecraft.core.world.World;
import useless.legacyui.gui.screens.GuiLegacyCrafting;
import useless.legacyui.gui.slots.SlotCraftingDisplayLegacy;
import useless.legacyui.gui.slots.SlotNull;
import useless.legacyui.gui.slots.SlotResizable;
import useless.legacyui.helper.InventoryHelper;
import useless.legacyui.LegacyUI;
import useless.legacyui.sorting.LegacyCategoryManager;
import useless.legacyui.sorting.recipe.RecipeCategory;
import useless.legacyui.sorting.recipe.RecipeCost;
import useless.legacyui.sorting.recipe.RecipeGroup;

import java.util.List;
import java.util.Map;

public class LegacyContainerCrafting extends MenuAbstract {
    public ContainerCrafting craftMatrix;
    public Container craftResult = new ContainerResult();
    private final World world;
    private final int x;
    private final int y;
    private final int z;
    private final int craftingSize;
    private final ContainerInventory inventoryPlayer;
    public static int inventorySlotsStart = 10;
    public LegacyContainerCrafting(final ContainerInventory inventoryplayer, final int craftingSize) {
        this(inventoryplayer, null, 0, 0, 0, craftingSize);
    }
    public LegacyContainerCrafting(final ContainerInventory inventoryplayer, final World world, final int x, final int y, final int z, final int craftingSize) {
        if (craftingSize <= 4){
            this.craftMatrix = new ContainerCrafting(this, 2, 2);
        } else {
            this.craftMatrix = new ContainerCrafting(this, 3, 3);
        }
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.craftingSize = craftingSize;
        this.inventoryPlayer = inventoryplayer;
    }
    public void craftingSlots(final boolean showCraftingPreview) {
        this.addSlot(new SlotResult(this.inventoryPlayer.player, this.craftMatrix, this.craftResult, 0, showCraftingPreview ? -5000 : 107, showCraftingPreview ? -5000 : 127));
        int baseIterator;
        int subIterator;

        if (this.craftingSize <= 4){
            // 2x2 Crafting
            for (baseIterator = 0; baseIterator < 2; ++baseIterator) {
                for (subIterator = 0; subIterator < 2; ++subIterator) {
                    this.addSlot(new Slot(this.craftMatrix, subIterator + baseIterator * 2, 29 + subIterator * 18, 118 + baseIterator * 18));
                }
            }
            for (baseIterator = 0; baseIterator < 4; ++baseIterator) {
                this.addSlot(new SlotNull(this.inventoryPlayer, this.inventoryPlayer.getContainerSize() - 1 - baseIterator, -5000, -5000));
            }
        }
        else {
            // 3x3 Crafting
            for (baseIterator = 0; baseIterator < 3; ++baseIterator) {
                for (subIterator = 0; subIterator < 3; ++subIterator) {
                    final int x = showCraftingPreview ? -5000 : 20 + subIterator * 18;
                    final int y = showCraftingPreview ? -5000 : 109 + baseIterator * 18;
                    this.addSlot(new Slot(this.craftMatrix, subIterator + baseIterator * 3, x, y));
                }
            }
        }
        inventorySlotsStart = this.slots.size();
        // 3x9 inventory
        for (baseIterator = 0; baseIterator < 3; ++baseIterator) {
            for (subIterator = 0; subIterator < 9; ++subIterator) {
                this.addSlot(new SlotResizable(this.inventoryPlayer, subIterator + baseIterator * 9 + 9, 152 + subIterator * 12, 112 + baseIterator * 12, 12));
            }
        }
        // 1x9 hotbar
        for (baseIterator = 0; baseIterator < 9; ++baseIterator) {
            this.addSlot(new SlotResizable(this.inventoryPlayer, baseIterator, 152 + baseIterator * 12, 154, 12));
        }

        this.slotsChanged(this.craftMatrix);
    }
    public void setRecipes(final Player player, final StatsCounter statCounter, final boolean showCraftingPreview){
//        Random random = new Random();
        final boolean isInInventory = this.craftingSize <= 4;

        final int currentSlotId = GuiLegacyCrafting.currentSlot;
        final int currentScrollAmount = GuiLegacyCrafting.currentScroll;
        final int categoryIndex = GuiLegacyCrafting.currentTab;

        final RecipeCategory category = LegacyCategoryManager.getRecipeCategories().get(categoryIndex);

        for (final RecipeGroup group : category.getRecipeGroups(isInInventory)){
            LegacyUI.LOGGER.debug("CategoryGroup: " + group.getOutputStack(0, isInInventory).getItem().namespaceID);
        }
        LegacyUI.LOGGER.debug("Category: " + category + " | slotId: " + currentSlotId + " | currentScroll: " + currentScrollAmount + " | craftPreview: " + showCraftingPreview);
        this.slots.clear();
        craftingSlots(showCraftingPreview);

        final RecipeGroup[] craftingGroups = category.getRecipeGroups(isInInventory);
        boolean discovered;
        ItemStack item;

        int index = 0;
        for (final RecipeGroup group : craftingGroups){
            final RecipeEntryCrafting<?, ?> recipe;
            boolean craftable;
            if (index == currentSlotId){ // special rendering for scrolling and recipe preview
                recipe = group.getRecipe(currentScrollAmount, isInInventory);
                craftable = canCraft(player, new RecipeCost(recipe));

                // Recipebar preview
                item = (ItemStack) recipe.getOutput();
                discovered = isDicovered(item, statCounter, player);
                this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 12 + 18 * index, 51, item, discovered, !craftable, LegacySettings.HIGHLIGHT_COLOR.value.value, false));

                if (group.getRecipes(isInInventory).size() > 1) { // If multiple Items in recipe group
                    final int idUpper = currentScrollAmount + 1; // Next item in group
                    final int idLower = currentScrollAmount - 1; // Last item in group

                    // Next item preview
                    item = group.getOutputStack(idUpper, isInInventory);
                    discovered = isDicovered(item, statCounter, player);
                    craftable = canCraft(player, new RecipeCost(group.getRecipe(idUpper, isInInventory)));
                    this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 12 + 18 * index, 51 + 21, item, discovered, !craftable, LegacySettings.HIGHLIGHT_COLOR.value.value, false));

                    // Previous item preview
                    item = group.getOutputStack(idLower, isInInventory);
                    discovered = isDicovered(item, statCounter, player);
                    craftable = canCraft(player, new RecipeCost(group.getRecipe(idLower, isInInventory)));
                    this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 12 + 18 * index, 51 - 21, item, discovered, !craftable, LegacySettings.HIGHLIGHT_COLOR.value.value, false));

                }

                // Crafting table result preview
                final int offset = showCraftingPreview ? 0:5000;
                final RecipeCost cost = new RecipeCost(recipe);
                craftable = canCraft(player, cost);
                item = (ItemStack) recipe.getOutput();
                discovered = isDicovered(item, statCounter, player);
                this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 103, 123+offset, item, discovered, !craftable, LegacySettings.HIGHLIGHT_COLOR.value.value, 26, false));

                final RecipeSymbol[] inputSymbols = InventoryHelper.getRecipeInput(recipe);
                for (int j = 0; j < inputSymbols.length; j++) {

                    final RecipeSymbol itemSymbol;
                    if (inputSymbols[j] != null){
                        itemSymbol = inputSymbols[j];
                        final List<ItemStack> resolved = itemSymbol.resolve();
                        item = resolved.get(0/*random.nextInt(resolved.size())*/);
                    } else {
                        itemSymbol = null;
                        item = null;
                    }

                    discovered = isDicovered(item, statCounter, player);

                    final RecipeSymbol[] costSymbols = cost.costMap.keySet().toArray(new RecipeSymbol[0]);
                    int k = 0;
                    if (itemSymbol != null){
                        for (int i = 0; i < costSymbols.length; i++){
                            if (costSymbols[i].equals(itemSymbol)){
                                cost.costMap.put(costSymbols[i], cost.costMap.get(costSymbols[i]) - 1);
                                k = i;
                                break;
                            }
                        }
                    }
                    final int num = cost.costMap.get(costSymbols[k]);
                    if (inputSymbols.length > 5){
                        // Render 3x3 crafting grid
                        this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 20 + 18 * (j % 3), 109 + offset + 18 * (j / 3), item, discovered, InventoryHelper.itemsInInventory(this.inventoryPlayer, itemSymbol) <= num && item != null, LegacySettings.HIGHLIGHT_COLOR.value.value, true));
                    }
                    else {
                        // Render 2x2 crafting gird
                        this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 29 + 18 * (j % 2), 118 + offset + 18 * (j / 2), item, discovered, InventoryHelper.itemsInInventory(this.inventoryPlayer, itemSymbol) <= num && item != null, LegacySettings.HIGHLIGHT_COLOR.value.value, true));
                    }


                }
            }
            else { // Renders first Slot of none selected groups
                item = group.getOutputStack(0, isInInventory);
                discovered = isDicovered(item, statCounter, player);
                craftable = canCraft(player, new RecipeCost(group.getRecipe(0, isInInventory)));
                this.addSlot(new SlotCraftingDisplayLegacy(this.slots.size(), 12 + 18 * index, 51, item, discovered, !craftable, LegacySettings.HIGHLIGHT_COLOR.value.value, false));
            }

            index++;
        }
    }
    public boolean craft(final Minecraft mc, final int windowId){
        final boolean isInInventory = this.craftingSize <= 4;

        final int currentSlotId = GuiLegacyCrafting.currentSlot;
        final int currentScrollAmount = GuiLegacyCrafting.currentScroll;
        final int categoryIndex = GuiLegacyCrafting.currentTab;

        final RecipeCategory category = LegacyCategoryManager.getRecipeCategories().get(categoryIndex);

        final RecipeEntryCrafting<?, ?> recipe = category.getRecipeGroups(isInInventory)[currentSlotId].getRecipe(currentScrollAmount, isInInventory);
        final RecipeCost recipeCost = new RecipeCost(recipe);

        final RecipeSymbol[] recipeInput = InventoryHelper.getRecipeInput(recipe);
        if (canCraft(mc.thePlayer, recipeCost)){
            for (int i = 0; i < recipeInput.length; i++){
                int slotId = InventoryHelper.findStackIndex(mc.thePlayer.inventory.mainInventory, recipeInput[i]); // Finds Slot index of an inventory Slot with a desired item
                if (slotId == -1) {continue;}
                if (slotId < 9){ slotId += 36;}


                if (isInInventory){
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_LEFT, new int[]{slotId}, mc.thePlayer); // Picks up stack
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_RIGHT, new int[]{i+1}, mc.thePlayer); // Places one item
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_LEFT, new int[]{slotId}, mc.thePlayer); // Puts down stack
                }
                else if (recipeInput.length > 5){// 3x3 crafting
                    final int offset = 1;
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_LEFT, new int[]{slotId + offset}, mc.thePlayer); // Picks up stack
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_RIGHT, new int[]{i+1}, mc.thePlayer); // Places one item
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_LEFT, new int[]{slotId + offset}, mc.thePlayer); // Puts down stack
                }
                else {// 2x2 crafting
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_LEFT, new int[]{slotId + 1}, mc.thePlayer); // Picks up stack
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_RIGHT, new int[]{i + ((i + 1)/3) + 1}, mc.thePlayer); // Places one item
                    mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.CLICK_LEFT, new int[]{slotId + 1}, mc.thePlayer); // Puts down stack
                }
            }
            mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.MOVE_STACK, new int[]{0}, mc.thePlayer);
            mc.playerController.handleInventoryMouseClick(windowId, InventoryAction.DROP, new int[]{0}, mc.thePlayer);
            return true; // Craft succeeded
        }
        return false; // Craft failed
    }
    private boolean canCraft(final Player player, final RecipeCost cost){
        boolean canCraft = true;
        for (final Map.Entry<RecipeSymbol, Integer> entry : cost.costMap.entrySet()){
            canCraft = canCraft && InventoryHelper.itemsInInventory(player.inventory, entry.getKey()) >= entry.getValue();
        }
        return canCraft;
    }
    public static boolean isDicovered(final ItemStack item, final StatsCounter statWriter, final Player player){
        if (!LegacySettings.CRAFTING_HIDE_UNDISCOVERED_ITEMS.value){
            return true;
        }
        if (player.getGamemode() == Gamemodes.CREATIVE) {
            return true;
        }
        if (item == null) {
            return false;
        } else {
            return statWriter.readStat(item.getItem().getStat(StatList.STAT_PICKED_UP)) > 0;
        }
    }


    @Override
    public void slotsChanged(final Container iinventory) {
        this.craftResult.setItem(0, Registries.RECIPES.findMatchingRecipe(this.craftMatrix));
    }

    @Override
    public void onCraftGuiClosed(final Player player) {
        super.onCraftGuiClosed(player);
        boolean insert = false;
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemstack = this.craftMatrix.getItem(i);
            if (itemstack == null) continue;
            this.storeOrDropItem(player, itemstack);
            insert = true;
        }
        if (insert) {
            player.world.playSoundAtEntity(player, player, "random.insert", 0.1f, 1.0f);
        }
    }

    @Override
    public boolean stillValid(final Player entityplayer) {
        if (this.craftingSize <=4 ){ // Inventory Crafting
            return true;
        }
        if (this.world.getBlockId(this.x, this.y, this.z) != Blocks.WORKBENCH.id()) { // Supplied coords are not a crafting table
            return false;
        }
        return entityplayer.distanceToSqr((double)this.x + 0.5, (double)this.y + 0.5, (double)this.z + 0.5) <= 64.0; // Is close enough to table
    }

    @Override
    public IntList getMoveSlots(final InventoryAction action, final Slot slot, final int target, final Player player) {
        if (this.craftingSize > 4){
            if (slot.index == 0) {
                return this.getSlots(0, 1, false);
            }
            if (slot.index >= 1 && slot.index < 9) {
                return this.getSlots(1, 9, false);
            }
            if (action == InventoryAction.MOVE_SIMILAR) {
                if (slot.index >= 10 && slot.index <= 45) {
                    return this.getSlots(10, 36, false);
                }
            } else {
                if (slot.index >= 10 && slot.index <= 36) {
                    return this.getSlots(10, 27, false);
                }
                if (slot.index >= 37 && slot.index <= 45) {
                    return this.getSlots(37, 9, false);
                }
            }
        } else {
            if (slot.index == 0) {
                return this.getSlots(0, 1, false);
            }
            if (slot.index >= 1 && slot.index <= 4) {
                return this.getSlots(1, 4, false);
            }
            if (slot.index >= 5 && slot.index <= 8) {
                return this.getSlots(5, 4, false);
            }
            if (action == InventoryAction.MOVE_SIMILAR) {
                if (slot.index >= 9 && slot.index <= 44) {
                    return this.getSlots(9, 36, false);
                }
            } else {
                if (slot.index >= 9 && slot.index <= 35) {
                    return this.getSlots(9, 27, false);
                }
                if (slot.index >= 36 && slot.index <= 44) {
                    return this.getSlots(36, 9, false);
                }
            }
        }
        return null;

    }

    @Override
    public IntList getTargetSlots(final InventoryAction action, final Slot slot, final int target, final Player player) {
        if (this.craftingSize > 4){
            if (slot.index >= 10 && slot.index <= 45) {
                if (target == 1) {
                    return this.getSlots(1, 9, false);
                }
                if (slot.index >= 10 && slot.index <= 36) {
                    return this.getSlots(37, 9, false);
                }
                if (slot.index >= 37 && slot.index <= 45) {
                    return this.getSlots(10, 27, false);
                }
            } else {
                if (slot.index == 0) {
                    return this.getSlots(10, 36, true);
                }
                return this.getSlots(10, 36, false);
            }
            return null;
        } {
            if (slot.index >= 9 && slot.index <= 44) {
                if (target == 1) {
                    return this.getSlots(1, 4, false);
                }
                if (target == 2) {
                    return this.getSlots(5, 4, false);
                }
                if (slot.index < 36) {
                    return this.getSlots(36, 9, false);
                }
                return this.getSlots(9, 27, false);
            }
            if (slot.index == 0) {
                return this.getSlots(9, 36, true);
            }
            return this.getSlots(9, 36, false);
        }
    }
    public void handleHotbarSwap(final int[] args, final Player player) {
        if (args[0] > ((this.craftingSize <= 4) ? (5 + 4 + 27 -1):(10 + 27 -1))){
            return;
        }
        super.handleHotbarSwap(args, player);
    }
    public int getHotbarSlotId(final int number) {
        if (this.craftingSize <= 4){
            return 5 + 4 + 27 -1 + number;
        } else {
            return 10 + 27 -1 + number;
        }
    }
}
